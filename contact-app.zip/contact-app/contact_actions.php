<?php
include 'db.php';

$action = $_GET['action'] ?? '';

switch($action) {
    case "add":
        $data = json_decode(file_get_contents("php://input"), true);
        $stmt = $conn->prepare("INSERT INTO contacts (name, email, phone) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $data['name'], $data['email'], $data['phone']);
        $stmt->execute();
        break;

    case "list":
        $search = $_GET['search'] ?? '';
        $query = "SELECT * FROM contacts";
        if ($search) {
            $search = "%$search%";
            $stmt = $conn->prepare("SELECT * FROM contacts WHERE name LIKE ? OR email LIKE ?");
            $stmt->bind_param("ss", $search, $search);
            $stmt->execute();
            $result = $stmt->get_result();
        } else {
            $result = $conn->query($query);
        }
        $contacts = [];
        while ($row = $result->fetch_assoc()) {
            $contacts[] = $row;
        }
        echo json_encode($contacts);
        break;

    case "delete":
        $data = json_decode(file_get_contents("php://input"), true);
        $stmt = $conn->prepare("DELETE FROM contacts WHERE id = ?");
        $stmt->bind_param("i", $data['id']);
        $stmt->execute();
        break;

    case "update":
        $data = json_decode(file_get_contents("php://input"), true);
        $stmt = $conn->prepare("UPDATE contacts SET name=?, email=?, phone=? WHERE id=?");
        $stmt->bind_param("sssi", $data['name'], $data['email'], $data['phone'], $data['id']);
        $stmt->execute();
        break;
}
?>
