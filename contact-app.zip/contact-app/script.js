document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("contactForm");
    const idField = document.getElementById("contactId");

    loadContacts();

    form.onsubmit = function (e) {
        e.preventDefault();
        const contact = {
            id: idField.value,
            name: document.getElementById("name").value.trim(),
            email: document.getElementById("email").value.trim(),
            phone: document.getElementById("phone").value.trim()
        };

        const action = contact.id ? 'update' : 'add';

        fetch(`contact_actions.php?action=${action}`, {
            method: "POST",
            body: JSON.stringify(contact)
        }).then(() => {
            form.reset();
            idField.value = "";
            loadContacts();
        });
    };

    document.getElementById("search").addEventListener("keyup", function () {
        loadContacts(this.value);
    });
});

function loadContacts(search = '') {
    fetch(`contact_actions.php?action=list&search=${encodeURIComponent(search)}`)
        .then(res => res.json())
        .then(data => {
            const tbody = document.getElementById("contactList");
            tbody.innerHTML = "";

            data.forEach(c => {
                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td>${c.name}</td>
                    <td>${c.email}</td>
                    <td>${c.phone}</td>
                    <td>
                        <button class="btn btn-sm btn-warning" onclick='editContact(${JSON.stringify(c)})'>Edit</button>
                        <button class="btn btn-sm btn-danger" onclick='deleteContact(${c.id})'>Delete</button>
                    </td>`;
                tbody.appendChild(tr);
            });
        });
}

function editContact(c) {
    document.getElementById("contactId").value = c.id;
    document.getElementById("name").value = c.name;
    document.getElementById("email").value = c.email;
    document.getElementById("phone").value = c.phone;
}

function deleteContact(id) {
    if (!confirm("Delete this contact?")) return;
    fetch("contact_actions.php?action=delete", {
        method: "POST",
        body: JSON.stringify({ id })
    }).then(() => loadContacts());
}
