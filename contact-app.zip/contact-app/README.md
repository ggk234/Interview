# 📇 Contact Manager (PHP, MySQL, AJAX)

A simple contact management system using **PHP**, **MySQL**, **AJAX**, **Bootstrap**, and **vanilla JavaScript** — no frameworks.

---

Features

- ➕ Add new contacts (Name, Email, Phone)
- 📝 Edit contacts (with pre-filled form)
- ❌ Delete contacts
- 🔍 Live search by Name or Email
- ⚡ AJAX-powered (no page reloads)
- 💡 Clean Bootstrap UI
- ✅ Basic email validation (HTML5)

---

Database Setup

1. Open **phpMyAdmin** (or MySQL CLI)
2. Create a new database:

```sql
CREATE DATABASE contact_app;

CREATE TABLE contacts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100),
  phone VARCHAR(20)
);
