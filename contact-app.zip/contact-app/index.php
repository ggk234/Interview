<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Contact Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #343a40;
        }

        #contactForm {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        }

        input.form-control {
            border-radius: 6px;
        }

        .btn-primary {
            width: 150px;
        }

        #search {
            max-width: 400px;
            margin: 0 auto 20px auto;
            border-radius: 6px;
        }

        table.table {
            background-color: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        }

        table thead {
            background-color: #343a40;
            color: #fff;
        }

        table tbody tr:hover {
            background-color: #f1f1f1;
        }

        .table td, .table th {
            vertical-align: middle;
        }
    </style>
</head>
<body class="container mt-4">
    <h2>Contact Manager</h2>

    <form id="contactForm" class="row g-3 mb-4">
        <input type="hidden" id="contactId">
        <div class="col-md-4">
            <input type="text" id="name" class="form-control" placeholder="Name" required>
        </div>
        <div class="col-md-4">
            <input type="email" id="email" class="form-control" placeholder="Email" required>
        </div>
        <div class="col-md-4">
            <input type="text" id="phone" class="form-control" placeholder="Phone" required>
        </div>
        <div class="col-12 text-center">
            <button type="submit" class="btn btn-primary">Save Contact</button>
        </div>
    </form>

    <input type="text" id="search" class="form-control mb-3" placeholder="Search by name or email">

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Name</th><th>Email</th><th>Phone</th><th>Actions</th>
            </tr>
        </thead>
        <tbody id="contactList">
            <!-- Dynamic content goes here -->
        </tbody>
    </table>

    <script src="script.js"></script>
</body>
</html>
